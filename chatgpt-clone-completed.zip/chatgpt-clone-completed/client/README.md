# Lama Dev AI Chat Bot App Starter Setup

This template provides a minimal setup to get React 19 working in Vite with HMR and some ESLint rules.